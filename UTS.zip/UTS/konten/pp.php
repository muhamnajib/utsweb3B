<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Persegi Panjang</title>
</head>
<body>
    <center>
    <h1 style="padding-top: 150px;"></h1>
    <h1 style="color:white;">Persegi Panjang</h1>
<?php 

if (isset($_POST['submit'])){
    $panjang = $_POST['panjang'];
    $lebar = $_POST['lebar']; 

    $Lhasil=$panjang*$lebar;
    $Khasil=2*($panjang+$lebar);

    echo "<h2 style='color:black'>Panjang = ".$panjang." Lebar = ".$lebar."</h2>";

    echo "<h2 style='color:black;'>Luas Persegi Panjang adalah ".$Lhasil."</h2>";
    echo "<h2 style='color:black;'>Keliling Persegi Panjang adalah ".$Khasil."</h2>";

   }
   else{
?>
<form style="color:white;" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
<table>
  <tr><td>Masukkan Panjang</td><td>:</td><td><input type="text" name="panjang"></td></tr>
  <tr><td>Masukkan Lebar</td><td>:</td><td><input type="text" name="lebar"></td></tr>
</table>
<br><br>
<input type="submit" name="submit" value="SUBMIT">
</form>
<?php 
   }
?>
</center>
</body>
</html>

