<html>
<head>
  <title>Berat Ideal</title>
</head>
<body>
  <center>
  <h1 style="padding-top:70px;"></h1>
<h1 style="color:white;">Berat Ideal</h1>

<?php

if (isset($_POST['submit']))
{
  // jika yang diklik adalah tombol 'penjumlahan'

  $tinggi = $_POST['tinggi'];
  $berat = $_POST['berat'];

  $ideal = ($tinggi - 100)-(($tinggi-100)/10);
   if ($berat <= $ideal+2 && $berat >= $ideal-2) {
        echo "Berat Badan Anda Ideal";
   }
   else{
        echo "Berat Badan Anda Tidak Ideal";
   }
}
else
{
// jika tombol belum diklik maka tampilkan form untuk entri bilangan
?>

<form style="color:white;" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
<table>
  <tr><td>Masukkan tinggi badan</td><td>:</td><td><input type="text" name="tinggi"></td></tr>
  <tr><td>Masukkan berat badan</td><td>:</td><td><input type="text" name="berat"></td></tr>
</table>
<br><br>
<input type="submit" name="submit" value="SUBMIT">
</form>
<?php
}
// perintah $_SERVER['PHP_SELF'] menyatakan bahwa action dari submit form diarahkan ke script ini sendiri.
?>
</center>
</body>
</html>