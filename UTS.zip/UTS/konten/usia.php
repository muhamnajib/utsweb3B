<html>
<head>
	<title> Status Usia </title>
</head>

<body>
<center>

<?php
if(isset($_POST['Submit'])){
	$usia = $_POST['usia'];
	
	if($usia >= 0 && $usia <=5.4 ){
		echo "<h1> Anda Masih Balita</h1>";
	}
	else if($usia >= 5.5 && $usia <= 16.9 ){
		echo "<h1> Anda Masih Anak-Anak</h1>";
	}
	else if($usia >= 17 && $usia <= 50 ) {
		echo "<h1> Anda Sudah Dewasa</h1>";
	}
	else if($usia >50 ){
		echo "<h1> Anda Sudah TUA</h1>";
	}

	echo "<h2 style='color:black'>Usia anda adalah $usia </h2>";
}
else{
?>
<h1 style="padding-top:70px;"></h1>
<h1 style="color:white;">Status Usia</h1>
<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
<table style="color:white;">
	<tr><td>Masukkan Usia Anda </td><td>:</td><td><input type="text" name="usia"></td></tr>
</table>
<input type="submit" name="Submit" value="Submit">
</form>
<?php
}
?>


</center>
</body>

</html>