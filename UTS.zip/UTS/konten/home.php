<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body>
    <center>
    <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
            <h2 style="padding-top:150px;"></h2>
            <h2 style="color:white;">Assalamu'alaikum Wr. Wb</h2>
            <table style="color:white">
                <tr><td>Nama</td><td>:</td><td>Muhammad Najibullah</td></tr>
                <tr><td>NIM</td><td>:</td><td>11180910000053</td></tr>
                <tr><td>Prodi</td><td>:</td><td>Teknik Informatika (3B)</td></tr>
                </table>
                <p style="color:white">Terima Kasih</p> 
            </form>

    </center>
</body>
</html>