<!DOCTYPE html>
<html>
<head>
	<title>Project UTS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="back.jpg">

	<div class="box">
		<img src="book.png">
	</div>
	<div class="boxlong">
		<h1 class="namaweb">E-Learning UIN Syarif Hidayatullah Jakarta</h1>
		<p class="tanggal">Kamis, 21 November 2019</p>
	</div>
	<div class="list">
		<ul>
			<li><a href="?module=home#pos" style="color:white">Home</a></li>
			<hr>
			<li><a href="?module=pendaftaran#pos" style="color:white">Pendaftaran</a></li>
			<hr>
			<li><a href="?module=bb#pos" style="color:white">Mengukur berat badan ideal</a></li>
			<hr>
			<li><a href="?module=usia#pos" style="color:white">Menghitung kategori Usia</a></li>
			<hr>
			<li><a href="?module=pp#pos" style="color:white">Menghitung Persegi Panjang</a></li>
			<hr>
			<li><a href="?module=segitiga#pos" style="color:white">Menghitung Segitiga</a></li>
			<hr>
			<li><a href="?module=daftarmhs#pos" style="color:white">Daftar Mahasiswa</a></li>
			<hr>
		</ul>
	</div>
	<div class="content">
		<?php  
		if(isset($_GET['module']))
		include "konten/$_GET[module].php";
		else
		include "konten/usia.php";
		?>
	</div>
</body>
</html>